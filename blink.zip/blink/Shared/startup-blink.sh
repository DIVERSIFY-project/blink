#!/bin/bash

file_test=false

while [ "$file_test" != true ] ;
do
	if [ -f /media/sf_Shared/mainVM.py ];
	then 
		echo "TRUE `date`" >>  ~/blink.log ;
		file_test=true ;
	else 
		echo "FALSE `date`" >>  ~/blink.log ;
		sleep 1 ;
	fi

done

python3 /media/sf_Shared/mainVM.py >> blinkvm.log 2>&1